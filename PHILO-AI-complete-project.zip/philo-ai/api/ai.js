import OpenAI from "openai";

const client = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const tasks = {
  essay: "Rédige une dissertation philosophique complète et méthodique, avec introduction, problématique, développement argumenté, transitions et conclusion.",
  debate: "Rédige un article philosophique dialectique : présente la thèse, l'antithèse, examine leurs arguments, propose un dépassement ou une synthèse nuancée, puis conclus.",
  compare: "Réalise une comparaison philosophique structurée : définis les notions, établis les points communs, les différences, les arguments et une conclusion.",
  analyze: "Analyse le texte fourni. Distingue le thème, la problématique, la thèse, les concepts, les arguments, les exemples et la conclusion. N'invente pas d'éléments absents du texte.",
  solve: "Traite le sujet selon une méthode philosophique claire et adaptée au niveau indiqué, avec introduction, développement et conclusion.",
  intro: "Rédige une introduction problématisée et une conclusion pertinente pour le sujet.",
  plan: "Propose un plan détaillé et cohérent avec les parties, sous-parties, idées et transitions.",
  explain: "Explique clairement le concept, donne une définition, des distinctions utiles, des exemples et les difficultés philosophiques.",
  philosopher: "Présente le philosophe, le contexte de sa pensée, ses idées majeures et ses concepts. N'invente pas de citations ni de références.",
  arguments: "Propose des arguments pour et contre, des explications et des exemples pertinents. Signale clairement les citations incertaines et n'en fabrique aucune."
};

const levels = {
  secondary: "Niveau lycée / baccalauréat : explications accessibles, méthode scolaire rigoureuse.",
  university: "Niveau universitaire : analyse approfondie et distinctions conceptuelles précises.",
  simple: "Explication simple, progressive et accessible, avec des exemples.",
  advanced: "Niveau approfondi : analyse conceptuelle détaillée et discussion nuancée."
};

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Méthode non autorisée." });
  }

  if (!process.env.OPENAI_API_KEY) {
    return res.status(500).json({
      error: "OPENAI_API_KEY_MISSING: ajoutez la clé dans les variables d'environnement Vercel."
    });
  }

  const body = req.body || {};
  const question = typeof body.question === "string" ? body.question.trim() : "";
  const mode = body.mode;
  const level = body.level;
  const language = body.language === "ar" ? "ar" : "fr";

  if (!question || question.length > 5000) {
    return res.status(400).json({ error: "Le sujet doit contenir entre 1 et 5000 caractères." });
  }
  if (!Object.prototype.hasOwnProperty.call(tasks, mode)) {
    return res.status(400).json({ error: "Service philosophique invalide." });
  }

  const languageName = language === "ar" ? "Arabic (Modern Standard Arabic)" : "French";
  const levelInstruction = levels[level] || levels.secondary;

  try {
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6.2-astra",
      instructions: [
        "Tu es PHILO AI, un assistant pédagogique spécialisé en philosophie.",
        `Réponds uniquement en ${languageName}.`,
        levelInstruction,
        tasks[mode],
        "Structure la réponse avec des titres et paragraphes lisibles.",
        "Sois exact, nuancé et pédagogique. N'invente ni citations, ni auteurs, ni références.",
        "Si une information est incertaine, indique-le. Si le sujet est ambigu, explique brièvement l'ambiguïté."
      ].join("\n\n"),
      input: question
    });

    const answer = response.output_text;
    if (!answer) {
      return res.status(502).json({ error: "Le modèle n'a pas renvoyé de texte." });
    }
    return res.status(200).json({ answer });
  } catch (error) {
    console.error("PHILO AI API error:", error);
    return res.status(502).json({
      error: "Échec de l'appel au fournisseur IA. Vérifiez le modèle, la clé API et la facturation."
    });
  }
}
