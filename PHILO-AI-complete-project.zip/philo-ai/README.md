# PHILO AI

Site bilingue (français/arabe) pour créer et analyser des travaux philosophiques avec l'API OpenAI.

## Fichiers

- `index.html` : interface complète (responsive, boutons de services, thème clair/sombre, FR/AR).
- `api/ai.js` : fonction serveur Vercel qui appelle l'API OpenAI.
- `package.json` : dépendance officielle OpenAI.
- `vercel.json` : configuration Vercel minimale.

## Déploiement avec GitHub + Vercel

1. Créez un nouveau dépôt GitHub et téléversez tous les fichiers en conservant cette structure :
   - `index.html`
   - `package.json`
   - `vercel.json`
   - `api/ai.js`
2. Sur Vercel, choisissez **Add New → Project**, importez ce dépôt GitHub, puis déployez.
3. Dans les paramètres du projet Vercel, ouvrez **Environment Variables** et ajoutez :
   - `OPENAI_API_KEY` = votre clé API privée
   - `OPENAI_MODEL` = `gpt-6.2-astra` (ou un modèle auquel votre compte API a accès)
4. Redéployez le projet après avoir ajouté/modifié les variables.
5. Ouvrez le domaine Vercel du projet. L'interface appelle `/api/ai` sur le même domaine.

## Sécurité et coûts

- Ne mettez jamais `OPENAI_API_KEY` dans `index.html`, dans GitHub, ni dans un dépôt public.
- L'API OpenAI est facturée séparément de ChatGPT. Vérifiez les tarifs et les limites de votre compte.
- Le modèle configuré doit être disponible pour votre compte API. Si ce n'est pas le cas, remplacez `OPENAI_MODEL` par un modèle proposé dans votre compte.
- Avant d'ouvrir le site au public, ajoutez une protection anti-abus (authentification, quotas ou rate limiting) et surveillez les dépenses API.

## Dépannage

- `OPENAI_API_KEY_MISSING` : variable absente ou mal orthographiée dans Vercel ; ajoutez-la puis redéployez.
- Erreur 404 sur `/api/ai` : vérifiez que le dossier `api` est à la racine du dépôt, au même niveau que `index.html`.
- Erreur liée au modèle : vérifiez `OPENAI_MODEL` et les accès de votre compte API.
- Erreur de facturation/quota : vérifiez la facturation et les limites de votre compte API.

GitHub Pages seul ne peut pas exécuter cette fonction serveur. Le projet doit être déployé sur Vercel (ou un hébergeur prenant en charge les fonctions Node.js).
